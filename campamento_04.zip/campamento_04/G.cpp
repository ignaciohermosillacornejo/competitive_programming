#include <bits/stdc++.h>
using namespace std;
#define debugx(x) cerr << #x << ": " << x << endl
#define rep(i, n) for (int i = 0; i < n; ++i)
typedef long long ll;
typedef vector<char> vi;
typedef pair<int, int> par;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef vector<vll> vvll;
typedef vector<vector<char>> graph;
typedef vector<vector<par>> wgraph;

int dfs(graph &g, int row, int col, int M, int N, int count)
{
    g[row][col] = 'w';
    int ans = count;
    if (row > 0 and g[row - 1][col] == 'l') // up
        ans += dfs(g, row - 1, col, M, N, 1);
    if (row + 1 < M and g[row + 1][col] == 'l') // down
        ans += dfs(g, row + 1, col, M, N, 1);
    if (g[row][(col + 1) % N] == 'l') // right
        ans += dfs(g, row, (col + 1) % N, M, N, 1);
    if (g[row][(col + N - 1) % N] == 'l') // left
        ans += dfs(g, row, (col + N - 1) % N, M, N, 1);
    return ans;
}

int main()
{
    int N;
    int M;
    while(cin >> M >> N)
    {
        graph g(M, vi(N, 'l'));
        rep(row, M)
        {
            rep(col, N)
            {
                cin >> g[row][col];
            }
        }
        int X;
        int Y;
        cin >> X >> Y;
        dfs(g, X, Y, M, N, 1);
        int max_count = 0;
        
        rep(row, M)
        {
            rep(col, N)
            {
                if (g[row][col] == 'l')
                    max_count = max(max_count, dfs(g, row, col, M, N, 1));
            }
        }
        cout << max_count << "\n";
    }
}